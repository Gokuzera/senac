from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, EmailField, PasswordField
from wtforms.validators import DataRequired, Email, Length

class CommentForm(FlaskForm):
    name = StringField('Nome', validators=[DataRequired(), Length(min=2, max=100)])
    email = EmailField('Email', validators=[Email()])
    content = TextAreaField('Comentário', validators=[DataRequired(), Length(min=10, max=1000)])

class ContactForm(FlaskForm):
    name = StringField('Nome', validators=[DataRequired(), Length(min=2, max=100)])
    email = EmailField('Email', validators=[DataRequired(), Email()])
    subject = StringField('Assunto', validators=[Length(max=200)])
    message = TextAreaField('Mensagem', validators=[DataRequired(), Length(min=10, max=2000)])

class AdminLoginForm(FlaskForm):
    username = StringField('Usuário', validators=[DataRequired()])
    password = PasswordField('Senha', validators=[DataRequired()])