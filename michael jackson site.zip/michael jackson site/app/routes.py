from flask import Blueprint, render_template, jsonify, request, redirect, url_for, flash
from app import db
from app.models import Album, TimelineEvent, GalleryImage, Video, Comment, ContactMessage
from app.forms import CommentForm, ContactForm
from flask_wtf.csrf import validate_csrf
from wtforms import ValidationError
import json

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    return render_template('index.html')

@main_bp.route('/biography')
def biography():
    return render_template('biography.html')

@main_bp.route('/timeline')
def timeline():
    events = TimelineEvent.query.order_by(TimelineEvent.year).all()
    return render_template('timeline.html', events=events)

@main_bp.route('/discography')
def discography():
    albums = Album.query.order_by(Album.year.desc()).all()
    return render_template('discography.html', albums=albums)

@main_bp.route('/gallery')
def gallery():
    images = GalleryImage.query.order_by(GalleryImage.created_at.desc()).all()
    return render_template('gallery.html', images=images)

@main_bp.route('/videos')
def videos():
    videos = Video.query.order_by(Video.created_at.desc()).all()
    return render_template('videos.html', videos=videos)

@main_bp.route('/legacy')
def legacy():
    return render_template('legacy.html')

@main_bp.route('/contact', methods=['GET', 'POST'])
def contact():
    form = ContactForm()
    if form.validate_on_submit():
        message = ContactMessage(
            name=form.name.data,
            email=form.email.data,
            subject=form.subject.data,
            message=form.message.data
        )
        db.session.add(message)
        db.session.commit()
        flash('Sua mensagem foi enviada com sucesso!', 'success')
        return redirect(url_for('main.contact'))
    return render_template('contact.html', form=form)

@main_bp.route('/about')
def about():
    return render_template('about.html')

# API Routes
@main_bp.route('/api/albums')
def api_albums():
    albums = Album.query.order_by(Album.year.desc()).all()
    return jsonify([album.to_dict() for album in albums])

@main_bp.route('/api/albums/<int:id>')
def api_album(id):
    album = Album.query.get_or_404(id)
    return jsonify(album.to_dict())

@main_bp.route('/api/timeline')
def api_timeline():
    events = TimelineEvent.query.order_by(TimelineEvent.year).all()
    events_data = [{
        'id': event.id,
        'year': event.year,
        'title': event.title,
        'description': event.description,
        'image': event.image
    } for event in events]
    return jsonify(events_data)

@main_bp.route('/api/comments', methods=['POST'])
def api_comments():
    try:
        validate_csrf(request.form.get('csrf_token'))
    except ValidationError:
        return jsonify({'error': 'Token CSRF inválido'}), 400
    
    data = request.get_json()
    comment = Comment(
        name=data.get('name'),
        email=data.get('email'),
        content=data.get('content')
    )
    db.session.add(comment)
    db.session.commit()
    return jsonify({'message': 'Comentário enviado para moderação'}), 201

@main_bp.route('/api/contact', methods=['POST'])
def api_contact():
    try:
        validate_csrf(request.form.get('csrf_token'))
    except ValidationError:
        return jsonify({'error': 'Token CSRF inválido'}), 400
    
    data = request.get_json()
    message = ContactMessage(
        name=data.get('name'),
        email=data.get('email'),
        subject=data.get('subject'),
        message=data.get('message')
    )
    db.session.add(message)
    db.session.commit()
    return jsonify({'message': 'Mensagem enviada com sucesso'}), 201