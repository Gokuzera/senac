from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from app import db
from app.models import Album, TimelineEvent, GalleryImage, Video, Comment, ContactMessage
from app.forms import AdminLoginForm
from config import Config
import bcrypt

admin_bp = Blueprint('admin', __name__)

# Simple user class for admin authentication
class User(UserMixin):
    def __init__(self, id):
        self.id = id

login_manager = LoginManager()

@login_manager.user_loader
def load_user(user_id):
    return User(user_id)

@admin_bp.record_once
def on_load(state):
    login_manager.init_app(state.app)
    login_manager.login_view = 'admin.login'
    login_manager.login_message = 'Por favor, faça login para acessar esta página.'

@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    form = AdminLoginForm()
    if form.validate_on_submit():
        config = Config()
        if (form.username.data == config.ADMIN_USERNAME and 
            form.password.data == config.ADMIN_PASSWORD):
            user = User(1)
            login_user(user)
            flash('Login realizado com sucesso!', 'success')
            return redirect(url_for('admin.dashboard'))
        else:
            flash('Credenciais inválidas!', 'error')
    return render_template('admin/login.html', form=form)

@admin_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logout realizado com sucesso!', 'success')
    return redirect(url_for('admin.login'))

@admin_bp.route('/')
@login_required
def dashboard():
    stats = {
        'albums': Album.query.count(),
        'comments_pending': Comment.query.filter_by(approved=False).count(),
        'messages': ContactMessage.query.count(),
        'images': GalleryImage.query.count()
    }
    return render_template('admin/dashboard.html', stats=stats)

@admin_bp.route('/comments')
@login_required
def manage_comments():
    comments = Comment.query.order_by(Comment.created_at.desc()).all()
    return render_template('admin/comments.html', comments=comments)

@admin_bp.route('/comments/<int:comment_id>/approve')
@login_required
def approve_comment(comment_id):
    comment = Comment.query.get_or_404(comment_id)
    comment.approved = True
    db.session.commit()
    flash('Comentário aprovado com sucesso!', 'success')
    return redirect(url_for('admin.manage_comments'))

@admin_bp.route('/comments/<int:comment_id>/delete')
@login_required
def delete_comment(comment_id):
    comment = Comment.query.get_or_404(comment_id)
    db.session.delete(comment)
    db.session.commit()
    flash('Comentário excluído com sucesso!', 'success')
    return redirect(url_for('admin.manage_comments'))

@admin_bp.route('/albums')
@login_required
def manage_albums():
    albums = Album.query.order_by(Album.year.desc()).all()
    return render_template('admin/albums.html', albums=albums)

@admin_bp.route('/messages')
@login_required
def manage_messages():
    messages = ContactMessage.query.order_by(ContactMessage.created_at.desc()).all()
    return render_template('admin/messages.html', messages=messages)