class AlbumSearch {
    constructor() {
        this.searchInput = document.getElementById('album-search');
        this.yearFilter = document.getElementById('year-filter');
        this.genreFilter = document.getElementById('genre-filter');
        this.albumsContainer = document.getElementById('albums-container');
        this.noResults = document.getElementById('no-results');
        this.albumCards = Array.from(document.querySelectorAll('.album-card'));
        
        this.init();
    }

    init() {
        // Event listeners
        if (this.searchInput) {
            this.searchInput.addEventListener('input', () => this.filterAlbums());
        }
        
        if (this.yearFilter) {
            this.yearFilter.addEventListener('change', () => this.filterAlbums());
        }
        
        if (this.genreFilter) {
            this.genreFilter.addEventListener('change', () => this.filterAlbums());
        }
        
        // Initial filter to handle any pre-set filters
        this.filterAlbums();
    }

    filterAlbums() {
        const searchTerm = this.searchInput ? this.searchInput.value.toLowerCase().trim() : '';
        const selectedYear = this.yearFilter ? this.yearFilter.value : '';
        const selectedGenre = this.genreFilter ? this.genreFilter.value.toLowerCase().trim() : '';
        
        let visibleCount = 0;

        this.albumCards.forEach(card => {
            const title = card.querySelector('.album-title').textContent.toLowerCase();
            const year = card.getAttribute('data-year');
            const genre = card.getAttribute('data-genre').toLowerCase();
            const description = card.querySelector('.album-description').textContent.toLowerCase();
            
            const matchesSearch = !searchTerm || 
                title.includes(searchTerm) || 
                description.includes(searchTerm);
            
            const matchesYear = !selectedYear || year === selectedYear;
            const matchesGenre = !selectedGenre || genre.includes(selectedGenre);
            
            if (matchesSearch && matchesYear && matchesGenre) {
                card.style.display = 'block';
                visibleCount++;
            } else {
                card.style.display = 'none';
            }
        });

        // Show/hide no results message
        if (this.noResults) {
            if (visibleCount === 0) {
                this.noResults.style.display = 'block';
            } else {
                this.noResults.style.display = 'none';
            }
        }

        // Update ARIA live region for screen readers
        this.updateLiveRegion(visibleCount);
    }

    updateLiveRegion(visibleCount) {
        let liveRegion = document.getElementById('search-live-region');
        
        if (!liveRegion) {
            liveRegion = document.createElement('div');
            liveRegion.id = 'search-live-region';
            liveRegion.setAttribute('aria-live', 'polite');
            liveRegion.setAttribute('aria-atomic', 'true');
            liveRegion.className = 'sr-only';
            document.body.appendChild(liveRegion);
        }
        
        const total = this.albumCards.length;
        let message;
        
        if (visibleCount === 0) {
            message = 'Nenhum álbum encontrado com os critérios de busca.';
        } else if (visibleCount === total) {
            message = `Mostrando todos os ${total} álbuns.`;
        } else {
            message = `Mostrando ${visibleCount} de ${total} álbuns.`;
        }
        
        liveRegion.textContent = message;
    }
}

// Initialize search when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('album-search')) {
        new AlbumSearch();
    }
});

// Utility function for debouncing search input
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Enhanced search with debouncing for better performance
class DebouncedAlbumSearch extends AlbumSearch {
    constructor() {
        super();
        this.debouncedFilter = debounce(() => this.filterAlbums(), 300);
    }

    init() {
        if (this.searchInput) {
            this.searchInput.addEventListener('input', () => this.debouncedFilter());
        }
        
        if (this.yearFilter) {
            this.yearFilter.addEventListener('change', () => this.debouncedFilter());
        }
        
        if (this.genreFilter) {
            this.genreFilter.addEventListener('change', () => this.debouncedFilter());
        }
        
        this.filterAlbums();
    }
}

// Use debounced version for better performance
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('album-search')) {
        new DebouncedAlbumSearch();
    }
});