// Navigation
class Navigation {
    constructor() {
        this.navToggle = document.querySelector('.nav-toggle');
        this.navMenu = document.querySelector('.nav-menu');
        this.init();
    }

    init() {
        this.navToggle.addEventListener('click', () => this.toggleMenu());
        this.navToggle.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.toggleMenu();
            }
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!this.navToggle.contains(e.target) && !this.navMenu.contains(e.target)) {
                this.closeMenu();
            }
        });

        // Close menu on escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeMenu();
            }
        });
    }

    toggleMenu() {
        const isExpanded = this.navToggle.getAttribute('aria-expanded') === 'true';
        this.navToggle.setAttribute('aria-expanded', !isExpanded);
        this.navMenu.classList.toggle('active');
    }

    closeMenu() {
        this.navToggle.setAttribute('aria-expanded', 'false');
        this.navMenu.classList.remove('active');
    }
}

// Theme Toggle
class ThemeToggle {
    constructor() {
        this.themeToggle = document.querySelector('.theme-toggle');
        this.darkModeStylesheet = document.getElementById('dark-mode-stylesheet');
        this.themeIcon = this.themeToggle.querySelector('.theme-icon');
        this.init();
    }

    init() {
        // Check for saved theme preference or default to light
        const savedTheme = localStorage.getItem('theme') || 'light';
        this.setTheme(savedTheme);

        this.themeToggle.addEventListener('click', () => this.toggleTheme());
        this.themeToggle.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.toggleTheme();
            }
        });
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        this.setTheme(newTheme);
    }

    setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        
        if (theme === 'dark') {
            this.darkModeStylesheet.removeAttribute('disabled');
            this.themeIcon.textContent = '☀️';
        } else {
            this.darkModeStylesheet.setAttribute('disabled', 'true');
            this.themeIcon.textContent = '🌙';
        }
        
        localStorage.setItem('theme', theme);
    }
}

// Back to Top
class BackToTop {
    constructor() {
        this.button = document.querySelector('.back-to-top');
        this.init();
    }

    init() {
        if (!this.button) return;

        window.addEventListener('scroll', () => this.toggleVisibility());
        this.button.addEventListener('click', () => this.scrollToTop());
        
        // Initial check
        this.toggleVisibility();
    }

    toggleVisibility() {
        if (window.pageYOffset > 300) {
            this.button.classList.add('visible');
        } else {
            this.button.classList.remove('visible');
        }
    }

    scrollToTop() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }
}

// Form Validation
class FormValidator {
    constructor(form) {
        this.form = form;
        this.fields = form.querySelectorAll('[required]');
        this.init();
    }

    init() {
        this.form.addEventListener('submit', (e) => this.validateForm(e));
        
        this.fields.forEach(field => {
            field.addEventListener('blur', () => this.validateField(field));
            field.addEventListener('input', () => this.clearError(field));
        });
    }

    validateForm(e) {
        let isValid = true;
        
        this.fields.forEach(field => {
            if (!this.validateField(field)) {
                isValid = false;
            }
        });

        if (!isValid) {
            e.preventDefault();
            this.focusFirstInvalid();
        }
    }

    validateField(field) {
        this.clearError(field);

        if (field.validity.valid) {
            return true;
        }

        const error = this.getErrorMessage(field);
        this.showError(field, error);
        return false;
    }

    getErrorMessage(field) {
        if (field.validity.valueMissing) {
            return 'Este campo é obrigatório.';
        }
        
        if (field.validity.typeMism) {
            if (field.type === 'email') {
                return 'Por favor, insira um email válido.';
            }
        }
        
        if (field.validity.tooShort) {
            return `O campo deve ter pelo menos ${field.minLength} caracteres.`;
        }
        
        return 'Por favor, preencha este campo corretamente.';
    }

    showError(field, message) {
        field.classList.add('error');
        
        const errorElement = document.createElement('div');
        errorElement.className = 'form-error';
        errorElement.textContent = message;
        errorElement.id = `${field.id}-error`;
        
        field.setAttribute('aria-describedby', errorElement.id);
        field.parentNode.appendChild(errorElement);
    }

    clearError(field) {
        field.classList.remove('error');
        field.removeAttribute('aria-describedby');
        
        const existingError = field.parentNode.querySelector('.form-error');
        if (existingError) {
            existingError.remove();
        }
    }

    focusFirstInvalid() {
        const firstInvalid = this.form.querySelector('.error');
        if (firstInvalid) {
            firstInvalid.focus();
        }
    }
}

// Lazy Loading
class LazyLoader {
    constructor() {
        this.images = document.querySelectorAll('img[data-src]');
        this.init();
    }

    init() {
        if ('IntersectionObserver' in window) {
            this.observeImages();
        } else {
            this.loadImagesImmediately();
        }
    }

    observeImages() {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.loadImage(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        });

        this.images.forEach(image => imageObserver.observe(image));
    }

    loadImagesImmediately() {
        this.images.forEach(image => this.loadImage(image));
    }

    loadImage(img) {
        img.src = img.dataset.src;
        img.removeAttribute('data-src');
        img.onload = () => img.classList.add('loaded');
    }
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new Navigation();
    new ThemeToggle();
    new BackToTop();
    new LazyLoader();

    // Initialize form validation for all forms
    document.querySelectorAll('form').forEach(form => {
        new FormValidator(form);
    });

    // Add loading states to buttons
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', (e) => {
            const submitButton = form.querySelector('button[type="submit"]');
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.textContent = 'Enviando...';
                
                // Re-enable button if form submission fails
                setTimeout(() => {
                    submitButton.disabled = false;
                    submitButton.textContent = submitButton.dataset.originalText || 'Enviar';
                }, 5000);
            }
        });
    });
});

// Utility function for API calls
class ApiClient {
    static async get(url) {
        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error('Network response was not ok');
            return await response.json();
        } catch (error) {
            console.error('API GET error:', error);
            throw error;
        }
    }

    static async post(url, data) {
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });
            
            if (!response.ok) throw new Error('Network response was not ok');
            return await response.json();
        } catch (error) {
            console.error('API POST error:', error);
            throw error;
        }
    }
}