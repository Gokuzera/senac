class Carousel {
    constructor(container) {
        this.container = container;
        this.track = container.querySelector('.carousel-track');
        this.slides = Array.from(container.querySelectorAll('.carousel-slide'));
        this.prevBtn = container.querySelector('.carousel-prev');
        this.nextBtn = container.querySelector('.carousel-next');
        this.dotsContainer = container.querySelector('.carousel-dots');
        this.currentIndex = 0;
        this.autoPlayInterval = null;
        this.autoPlayDelay = 5000; // 5 seconds
        
        this.init();
    }

    init() {
        // Create dots if container exists
        if (this.dotsContainer) {
            this.createDots();
        }
        
        // Event listeners
        if (this.prevBtn) {
            this.prevBtn.addEventListener('click', () => this.prev());
        }
        
        if (this.nextBtn) {
            this.nextBtn.addEventListener('click', () => this.next());
        }
        
        // Keyboard navigation
        this.container.addEventListener('keydown', (e) => this.handleKeydown(e));
        
        // Touch/swipe support
        this.setupTouchEvents();
        
        // Auto-play
        this.startAutoPlay();
        
        // Pause on hover
        this.container.addEventListener('mouseenter', () => this.stopAutoPlay());
        this.container.addEventListener('mouseleave', () => this.startAutoPlay());
        this.container.addEventListener('focusin', () => this.stopAutoPlay());
        this.container.addEventListener('focusout', () => this.startAutoPlay());
        
        // Initial update
        this.update();
    }

    createDots() {
        this.slides.forEach((_, index) => {
            const dot = document.createElement('button');
            dot.className = 'carousel-dot';
            dot.setAttribute('aria-label', `Ir para slide ${index + 1}`);
            dot.addEventListener('click', () => this.goToSlide(index));
            this.dotsContainer.appendChild(dot);
        });
        this.dots = Array.from(this.dotsContainer.querySelectorAll('.carousel-dot'));
    }

    update() {
        // Update track position
        this.track.style.transform = `translateX(-${this.currentIndex * 100}%)`;
        
        // Update dots
        if (this.dots) {
            this.dots.forEach((dot, index) => {
                dot.classList.toggle('active', index === this.currentIndex);
                dot.setAttribute('aria-current', index === this.currentIndex);
            });
        }
        
        // Update slide visibility for screen readers
        this.slides.forEach((slide, index) => {
            slide.setAttribute('aria-hidden', index !== this.currentIndex);
        });
        
        // Focus management for accessibility
        const currentSlide = this.slides[this.currentIndex];
        const focusableElements = currentSlide.querySelectorAll('button, a, [tabindex]');
        if (focusableElements.length > 0) {
            focusableElements[0].focus();
        }
    }

    next() {
        this.currentIndex = (this.currentIndex + 1) % this.slides.length;
        this.update();
    }

    prev() {
        this.currentIndex = (this.currentIndex - 1 + this.slides.length) % this.slides.length;
        this.update();
    }

    goToSlide(index) {
        this.currentIndex = index;
        this.update();
    }

    handleKeydown(e) {
        switch(e.key) {
            case 'ArrowLeft':
                e.preventDefault();
                this.prev();
                break;
            case 'ArrowRight':
                e.preventDefault();
                this.next();
                break;
            case 'Home':
                e.preventDefault();
                this.goToSlide(0);
                break;
            case 'End':
                e.preventDefault();
                this.goToSlide(this.slides.length - 1);
                break;
        }
    }

    setupTouchEvents() {
        let startX = 0;
        let currentX = 0;
        let isDragging = false;

        const handleStart = (clientX) => {
            startX = clientX;
            currentX = clientX;
            isDragging = true;
            this.track.style.transition = 'none';
        };

        const handleMove = (clientX) => {
            if (!isDragging) return;
            currentX = clientX;
            const diff = startX - currentX;
            this.track.style.transform = `translateX(calc(-${this.currentIndex * 100}% - ${diff}px))`;
        };

        const handleEnd = () => {
            if (!isDragging) return;
            isDragging = false;
            this.track.style.transition = '';

            const diff = startX - currentX;
            const threshold = 50;

            if (diff > threshold) {
                this.next();
            } else if (diff < -threshold) {
                this.prev();
            } else {
                this.update();
            }
        };

        // Mouse events
        this.container.addEventListener('mousedown', (e) => {
            e.preventDefault();
            handleStart(e.clientX);
        });

        document.addEventListener('mousemove', (e) => {
            handleMove(e.clientX);
        });

        document.addEventListener('mouseup', handleEnd);

        // Touch events
        this.container.addEventListener('touchstart', (e) => {
            handleStart(e.touches[0].clientX);
        });

        document.addEventListener('touchmove', (e) => {
            handleMove(e.touches[0].clientX);
        });

        document.addEventListener('touchend', handleEnd);
    }

    startAutoPlay() {
        this.stopAutoPlay();
        this.autoPlayInterval = setInterval(() => {
            this.next();
        }, this.autoPlayDelay);
    }

    stopAutoPlay() {
        if (this.autoPlayInterval) {
            clearInterval(this.autoPlayInterval);
            this.autoPlayInterval = null;
        }
    }
}

// Initialize carousels when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.carousel').forEach(container => {
        new Carousel(container);
    });
});