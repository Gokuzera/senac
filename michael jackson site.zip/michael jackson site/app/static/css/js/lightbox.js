class Lightbox {
    constructor() {
        this.lightbox = document.getElementById('lightbox');
        this.lightboxImage = this.lightbox.querySelector('.lightbox-image');
        this.lightboxTitle = this.lightbox.querySelector('.lightbox-title');
        this.lightboxDescription = this.lightbox.querySelector('.lightbox-description');
        this.closeBtn = this.lightbox.querySelector('.lightbox-close');
        this.prevBtn = this.lightbox.querySelector('.lightbox-prev');
        this.nextBtn = this.lightbox.querySelector('.lightbox-next');
        
        this.images = [];
        this.currentIndex = 0;
        
        this.init();
    }

    init() {
        // Get all gallery images
        this.images = Array.from(document.querySelectorAll('.gallery-image'));
        
        // Add click event to gallery images
        this.images.forEach((img, index) => {
            img.addEventListener('click', () => this.open(index));
            img.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.open(index);
                }
            });
        });
        
        // Event listeners for lightbox controls
        this.closeBtn.addEventListener('click', () => this.close());
        this.prevBtn.addEventListener('click', () => this.prev());
        this.nextBtn.addEventListener('click', () => this.next());
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => this.handleKeydown(e));
        
        // Close on background click
        this.lightbox.addEventListener('click', (e) => {
            if (e.target === this.lightbox) {
                this.close();
            }
        });
    }

    open(index) {
        this.currentIndex = index;
        this.update();
        this.lightbox.classList.add('active');
        document.body.style.overflow = 'hidden'; // Prevent scrolling
        
        // Focus management
        this.closeBtn.focus();
    }

    close() {
        this.lightbox.classList.remove('active');
        document.body.style.overflow = '';
        
        // Return focus to the image that was clicked
        if (this.images[this.currentIndex]) {
            this.images[this.currentIndex].focus();
        }
    }

    prev() {
        this.currentIndex = (this.currentIndex - 1 + this.images.length) % this.images.length;
        this.update();
    }

    next() {
        this.currentIndex = (this.currentIndex + 1) % this.images.length;
        this.update();
    }

    update() {
        const currentImage = this.images[this.currentIndex];
        
        // Set image source
        this.lightboxImage.src = currentImage.src;
        this.lightboxImage.alt = currentImage.alt;
        
        // Set caption
        const title = currentImage.getAttribute('data-title') || '';
        const description = currentImage.getAttribute('data-description') || '';
        
        this.lightboxTitle.textContent = title;
        this.lightboxDescription.textContent = description;
        
        // Hide caption if no content
        this.lightboxTitle.style.display = title ? 'block' : 'none';
        this.lightboxDescription.style.display = description ? 'block' : 'none';
        
        // Update ARIA labels for navigation
        this.prevBtn.setAttribute('aria-label', `Imagem anterior: ${this.getAdjacentTitle(-1)}`);
        this.nextBtn.setAttribute('aria-label', `Próxima imagem: ${this.getAdjacentTitle(1)}`);
    }

    getAdjacentTitle(offset) {
        const index = (this.currentIndex + offset + this.images.length) % this.images.length;
        const image = this.images[index];
        return image.getAttribute('data-title') || image.alt || 'Imagem sem título';
    }

    handleKeydown(e) {
        if (!this.lightbox.classList.contains('active')) return;
        
        switch(e.key) {
            case 'Escape':
                e.preventDefault();
                this.close();
                break;
            case 'ArrowLeft':
                e.preventDefault();
                this.prev();
                break;
            case 'ArrowRight':
                e.preventDefault();
                this.next();
                break;
            case 'Home':
                e.preventDefault();
                this.currentIndex = 0;
                this.update();
                break;
            case 'End':
                e.preventDefault();
                this.currentIndex = this.images.length - 1;
                this.update();
                break;
        }
    }
}

// Initialize lightbox when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('lightbox')) {
        new Lightbox();
    }
});