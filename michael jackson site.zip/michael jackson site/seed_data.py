from app import create_app, db
from app.models import Album, TimelineEvent, GalleryImage, Video

app = create_app()

def seed_data():
    with app.app_context():
        # Clear existing data
        print("Limpando dados existentes...")
        db.drop_all()
        db.create_all()

        # Add sample albums
        print("Adicionando álbuns...")
        albums = [
            Album(
                title="Got to Be There",
                year=1972,
                cover_image="/static/images/placeholder-album.jpg",
                tracks="Ain't No Sunshine, I Wanna Be Where You Are, Girl Don't Take Your Love From Me, In Our Small Way, Got to Be There, Rockin' Robin, Wings of My Love, Maria (You Were the Only One), Love Is Here and Now You're Gone, You've Got a Friend",
                description="Álbum de estreia solo de Michael Jackson, lançado quando ele tinha 13 anos. Mostrou seu talento vocal precoce e estabeleceu as bases para sua carreira solo.",
                genre="Soul, Pop, R&B"
            ),
            Album(
                title="Ben",
                year=1972,
                cover_image="/static/images/placeholder-album.jpg",
                tracks="Ben, Greatest Show on Earth, People Make the World Go 'Round, We've Got a Good Thing Going, Everybody's Somebody's Fool, My Girl, What Goes Around Comes Around, In Our Small Way, Shoo-Be-Doo-Be-Doo-Da-Day, You Can Cry on My Shoulder",
                description="Segundo álbum solo, contendo a música-título 'Ben' que se tornou seu primeiro single número 1 como artista solo.",
                genre="Soul, Pop"
            ),
            Album(
                title="Off the Wall",
                year=1979,
                cover_image="/static/images/placeholder-album.jpg",
                tracks="Don't Stop 'Til You Get Enough, Rock with You, Working Day and Night, Get on the Floor, Off the Wall, Girlfriend, She's Out of My Life, I Can't Help It, It's the Falling in Love, Burn This Disco Out",
                description="Álbum que marcou a transição de Michael Jackson de estrela infantil para artista adulto. Produzido por Quincy Jones, estabeleceu novo padrão para música disco e pop.",
                genre="Disco, Pop, R&B, Funk"
            ),
            Album(
                title="Thriller",
                year=1982,
                cover_image="/static/images/placeholder-album.jpg",
                tracks="Wanna Be Startin' Somethin', Baby Be Mine, The Girl Is Mine, Thriller, Beat It, Billie Jean, Human Nature, P.Y.T. (Pretty Young Thing), The Lady in My Life",
                description="O álbum mais vendido de todos os tempos. Revolucionou a indústria musical com seus videoclipes inovadores e produção impecável de Quincy Jones.",
                genre="Pop, R&B, Rock, Funk, Disco"
            ),
            Album(
                title="Bad",
                year=1987,
                cover_image="/static/images/placeholder-album.jpg",
                tracks="Bad, The Way You Make Me Feel, Speed Demon, Liberian Girl, Just Good Friends, Another Part of Me, Man in the Mirror, I Just Can't Stop Loving You, Dirty Diana, Smooth Criminal, Leave Me Alone",
                description="Seguindo o enorme sucesso de Thriller, Bad solidificou Michael Jackson como o 'Rei do Pop'. Produziu 5 singles número 1 na Billboard Hot 100.",
                genre="Pop, R&B, Funk, Rock"
            ),
            Album(
                title="Dangerous",
                year=1991,
                cover_image="/static/images/placeholder-album.jpg",
                tracks="Jam, Why You Wanna Trip on Me, In the Closet, She Drives Me Wild, Remember the Time, Can't Let Her Get Away, Heal the World, Black or White, Who Is It, Give In to Me, Will You Be There, Keep the Faith, Gone Too Soon, Dangerous",
                description="Primeiro álbum após o fim da parceria com Quincy Jones. Apresentou o 'New Jack Swing' e abordou temas sociais mais profundos.",
                genre="New Jack Swing, R&B, Pop, Funk"
            )
        ]

        # Add timeline events
        print("Adicionando eventos da linha do tempo...")
        timeline_events = [
            TimelineEvent(
                year=1958,
                title="Nascimento",
                description="Michael Joseph Jackson nasceu em 29 de agosto em Gary, Indiana, EUA. O sétimo de nove filhos de Joseph e Katherine Jackson."
            ),
            TimelineEvent(
                year=1964,
                title="Jackson 5",
                description="Michael e seus irmãos formam a banda Jackson 5. Michael, com apenas 6 anos, assume os vocais principais."
            ),
            TimelineEvent(
                year=1969,
                title="Primeiro Contrato",
                description="Jackson 5 assina com a Motown Records. Lançam 'I Want You Back' que se torna nº1 nas paradas."
            ),
            TimelineEvent(
                year=1971,
                title="Carreira Solo",
                description="Michael inicia carreira solo paralelamente ao Jackson 5, lançando 'Got to Be There'."
            ),
            TimelineEvent(
                year=1979,
                title="Off the Wall",
                description="Lançamento de 'Off the Wall', seu primeiro álbum como artista adulto. Vendeu mais de 20 milhões de cópias."
            ),
            TimelineEvent(
                year=1982,
                title="Thriller",
                description="Lançamento de 'Thriller', que se tornaria o álbum mais vendido da história com mais de 66 milhões de cópias."
            ),
            TimelineEvent(
                year=1983,
                title="Moonwalk",
                description="Primeira performance do moonwalk no especial 'Motown 25: Yesterday, Today, Forever', tornando-se instantaneamente icônica."
            ),
            TimelineEvent(
                year=1987,
                title="Bad World Tour",
                description="Início da turnê 'Bad', que se tornaria a turnê solo mais lucrativa da época, visitando 15 países."
            ),
            TimelineEvent(
                year=1988,
                title="Autobiografia",
                description="Lançamento da autobiografia 'Moonwalk', que se tornou best-seller do New York Times."
            ),
            TimelineEvent(
                year=1991,
                title="Dangerous",
                description="Lançamento do álbum 'Dangerous', marcando nova direção musical com produtores como Teddy Riley."
            ),
            TimelineEvent(
                year=1993,
                title="Super Bowl",
                description="Performance histórica no halftime show do Super Bowl XXVII para 133 milhões de espectadores."
            ),
            TimelineEvent(
                year=2001,
                title="30th Anniversary",
                description="Dois concertos de aniversário no Madison Square Garden com participações de diversos artistas."
            ),
            TimelineEvent(
                year=2009,
                title="This Is It",
                description="Anunciada turnê de retorno 'This Is It', infelizmente cancelada devido ao seu falecimento em 25 de junho."
            )
        ]

        # Add gallery images
        print("Adicionando imagens da galeria...")
        gallery_images = [
            GalleryImage(
                title="Michael Jackson Jovem",
                description="Michael Jackson em seus primeiros anos com os Jackson 5",
                image_path="/static/images/placeholder-gallery.jpg"
            ),
            GalleryImage(
                title="Performance no Palco",
                description="Michael durante uma de suas performances energéticas",
                image_path="/static/images/placeholder-gallery.jpg"
            ),
            GalleryImage(
                title="Sessão de Estúdio",
                description="Michael trabalhando no estúdio durante as gravações",
                image_path="/static/images/placeholder-gallery.jpg"
            ),
            GalleryImage(
                title="Prêmios Grammy",
                description="Michael com seus múltiplos prêmios Grammy",
                image_path="/static/images/placeholder-gallery.jpg"
            ),
            GalleryImage(
                title="Turnê Mundial",
                description="Durante uma de suas grandes turnês mundiais",
                image_path="/static/images/placeholder-gallery.jpg"
            ),
            GalleryImage(
                title="Ensaio Fotográfico",
                description="Sessão fotográfica profissional",
                image_path="/static/images/placeholder-gallery.jpg"
            )
        ]

        # Add videos
        print("Adicionando vídeos...")
        videos = [
            Video(
                title="Billie Jean - Motown 25",
                youtube_id="Zi_XLOBDo_Y",
                description="Performance histórica onde Michael apresentou o moonwalk pela primeira vez ao público"
            ),
            Video(
                title="Thriller - Videoclipe Completo",
                youtube_id="sOnqjkJTMaA",
                description="O videoclipe revolucionário que mudou a indústria musical para sempre"
            ),
            Video(
                title="Smooth Criminal",
                youtube_id="h_D3VFfhvs4",
                description="Videoclipe icônico com a famosa inclinação anti-gravidade"
            ),
            Video(
                title="Black or White",
                youtube_id="F2AitTPI5U0",
                description="Videoclipe com mensagem sobre igualdade racial e efeitos especiais inovadores"
            ),
            Video(
                title="Man in the Mirror - Grammy 1988",
                youtube_id="PivWY9wn5ps",
                description="Performance emocionante no Grammy Awards com coral gospel"
            ),
            Video(
                title="They Don't Care About Us",
                youtube_id="QNJL6nfu__Q",
                description="Videoclipe com fortes mensagens sociais e políticas"
            )
        ]

        # Add all to database
        for album in albums:
            db.session.add(album)
        
        for event in timeline_events:
            db.session.add(event)
        
        for image in gallery_images:
            db.session.add(image)
        
        for video in videos:
            db.session.add(video)

        db.session.commit()
        print("✅ Dados iniciais adicionados com sucesso!")
        print(f"📀 Álbuns: {len(albums)}")
        print(f"📅 Eventos: {len(timeline_events)}")
        print(f"🖼️ Imagens: {len(gallery_images)}")
        print(f"🎥 Vídeos: {len(videos)}")

if __name__ == '__main__':
    seed_data()