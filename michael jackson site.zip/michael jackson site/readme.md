# Site Michael Jackson

Site completo, responsivo e acessível sobre Michael Jackson desenvolvido com Flask (Python) no back-end e HTML/CSS/JavaScript no front-end.

## Características

- Design responsivo (mobile-first)
- Modo claro/escuro
- Navegação acessível
- Galeria com lightbox
- Sistema de comentários moderado
- Painel administrativo
- API REST
- Validação de formulários
- Carregamento lazy de imagens

## Pré-requisitos

- Python 3.8+
- pip (gerenciador de pacotes Python)
- SQLite (incluído no Python)

## Instalação

1. **Clone o repositório:**
```bash
git clone <repository-url>
cd michael-jackson-site